import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-where-we-are',
  templateUrl: './where-we-are.component.html',
  styleUrls: ['./where-we-are.component.scss']
})
export class WhereWeAreComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
