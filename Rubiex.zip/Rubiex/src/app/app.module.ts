import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MenuBarComponent } from './menu-bar/menu-bar.component';
import { CarouselComponent } from './carousel/carousel.component';
import { WhoWeAreComponent } from './who-we-are/who-we-are.component';
import { WhereWeAreComponent } from './where-we-are/where-we-are.component';
import { TrchForTeensComponent } from './trch-for-teens/trch-for-teens.component';
import { GetInTouchComponent } from './get-in-touch/get-in-touch.component';
import { FooterComponent } from './footer/footer.component';
import { CopywritesComponent } from './copywrites/copywrites.component';
import { LogoComponent } from './menu-bar/logo/logo.component';
import { NavItemsComponent } from './menu-bar/nav-items/nav-items.component';
import { AboutUsComponent } from './footer/about-us/about-us.component';
import { MenusComponent } from './footer/menus/menus.component';
import { LearnMoreComponent } from './footer/learn-more/learn-more.component';
import { AddressComponent } from './footer/address/address.component';

@NgModule({
  declarations: [
    AppComponent,
    MenuBarComponent,
    CarouselComponent,
    WhoWeAreComponent,
    WhereWeAreComponent,
    TrchForTeensComponent,
    GetInTouchComponent,
    FooterComponent,
    CopywritesComponent,
    LogoComponent,
    NavItemsComponent,
    AboutUsComponent,
    MenusComponent,
    LearnMoreComponent,
    AddressComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
