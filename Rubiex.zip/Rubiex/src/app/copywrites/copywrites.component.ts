import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-copywrites',
  templateUrl: './copywrites.component.html',
  styleUrls: ['./copywrites.component.scss']
})
export class CopywritesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
