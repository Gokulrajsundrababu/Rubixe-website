import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CopywritesComponent } from './copywrites.component';

describe('CopywritesComponent', () => {
  let component: CopywritesComponent;
  let fixture: ComponentFixture<CopywritesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CopywritesComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CopywritesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
