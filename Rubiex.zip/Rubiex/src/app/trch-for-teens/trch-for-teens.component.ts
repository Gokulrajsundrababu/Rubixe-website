import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-trch-for-teens',
  templateUrl: './trch-for-teens.component.html',
  styleUrls: ['./trch-for-teens.component.scss']
})
export class TrchForTeensComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
