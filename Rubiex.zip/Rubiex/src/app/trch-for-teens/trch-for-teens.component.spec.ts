import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TrchForTeensComponent } from './trch-for-teens.component';

describe('TrchForTeensComponent', () => {
  let component: TrchForTeensComponent;
  let fixture: ComponentFixture<TrchForTeensComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TrchForTeensComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TrchForTeensComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
